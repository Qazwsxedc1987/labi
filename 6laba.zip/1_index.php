<?php
$p = 1;
while ($p++ <= 100) {
    if ($p % 2 == 0) {
        echo $p . '<br>';
    }
}
