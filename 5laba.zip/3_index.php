<?php
$sqrt = sqrt(555);
$mass = ['floor' => floor($sqrt), 'ceil' => ceil($sqrt)];

echo 555 ** 0.5;

echo '<pre>';
var_dump($mass);
echo '</pre>';
