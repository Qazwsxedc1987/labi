<?php
// Создаем индексный массив с значениями от 1990 до 2000
$years = [];
for ($i = 1990; $i <= 2000; $i++) {
    $years[] = $i;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Годы</title>
</head>

<body>
    <h2>Выберите год:</h2>
    <select name="years">
        <?php foreach ($years as $year) : ?>
            <option value="<?php echo $year; ?>"><?php echo $year; ?></option>
        <?php endforeach; ?>
    </select>
</body>

</html>