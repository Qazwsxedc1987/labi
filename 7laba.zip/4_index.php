<?php
// Создание ассоциативного массива
$myArray = array(
    "name" => "Alice",
    "age" => 30,
    "city" => "New York",
    "occupation" => "Engineer",
    "email" => "alice@example.com"
);

// Вывод всех ключей массива в столбец
echo "<h2>Ключи ассоциативного массива:</h2>";
foreach ($myArray as $key => $value) {
    echo $key . "<br>";
}
