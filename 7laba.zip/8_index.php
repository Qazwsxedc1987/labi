<?php
// Создаем индексный массив с значениями от 2000 до 1990
$numbers = range(2000, 1990);

// Генерируем HTML элемент select с опциями из массива
$selectOptions = '';
foreach ($numbers as $number) {
    $selectOptions .= "<option value=\"$number\">$number</option>";
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Значения от 2000 до 1990</title>
</head>

<body>
    <h2>Выберите число:</h2>
    <select name="numbers">
        <?php echo $selectOptions; ?>
    </select>
</body>

</html>